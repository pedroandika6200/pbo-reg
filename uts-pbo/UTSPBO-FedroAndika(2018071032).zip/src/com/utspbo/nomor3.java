package com.utspbo;

import java.util.*;

class BilBul{
    int jmlbil;
    int[] bil = new int[20];
    int jml;
}

public class nomor3 {
    public static void main(String[] args) {
        BilBul akses = new BilBul();
        Scanner inputUser = new Scanner(System.in);
        System.out.print("Masukan jumlah bilangan yang akan diinput :");
        akses.jmlbil = inputUser.nextInt();
        for (int i = 1; i <= akses.jmlbil; i++) {
            System.out.print("Masukan bilangan ke-"+i+" : ");
            akses.bil[i] = inputUser.nextInt();
                }
        akses.jml = akses.bil[0]+akses.bil[1]+akses.bil[2]+akses.bil[3]+akses.bil[4]+akses.bil[5]+akses.bil[6]+akses.bil[7]+akses.bil[8]+akses.bil[9]+akses.bil[10]+akses.bil[11]+akses.bil[12]+akses.bil[13]+akses.bil[14]+akses.bil[15];

        System.out.println("Jumlah dari bilangan yang diinput : "+akses.jml);
    }
}
